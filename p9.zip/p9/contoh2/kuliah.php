<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid #ddd;
            text-align: center; /* Center-align text within cells */
        }

        th, td {
            padding: 12px;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
    <title>Nilai Santri</title>
</head>
<body>

<?php
// Include the class definition
require_once 'nilai.php';

// Create instances of the NilaiSantri class
$ns1 = new NilaiSantri('Fulan', 70);
$ns2 = new NilaiSantri('Badu', 69);
$ns3 = new NilaiSantri('Usro', 85);
$ns4 = new NilaiSantri('Jarwo', 40);

// Create an array of NilaiSantri objects
$ar_santri = [$ns1, $ns2, $ns3, $ns4];
?>

<table>
    <thead>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Nilai</th>
            <th>Hasil</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $nomor = 1;
        foreach ($ar_santri as $san) {
            echo '<tr>';
            echo '<td>' . $nomor . '</td>';
            echo '<td>' . $san->nama . '</td>';
            echo '<td>' . $san->nilai . '</td>';
            echo '<td>' . $san->getHasil() . '</td>';
            echo '</tr>';
            $nomor++;
        }
        ?>
    </tbody>
</table>

</body>
</html>
