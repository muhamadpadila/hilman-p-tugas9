<?php
// Include the class definition
require_once 'classFruit.php';

// Create instances of the Fruit class: $apple and $banana
$apple = new Fruit();
$banana = new Fruit();

// Call member class methods
$apple->set_name('Apple');
$apple->set_color('Red');
$banana->set_name('Banana');
$banana->set_color('Yellow');

// Display information about the fruits
echo 'Nama Buah ' . $apple->get_name() . ' Warnanya ' . $apple->get_color();
echo '<br/>Nama Buah ' . $banana->get_name() . ' Warnanya ' . $banana->get_color();
?>
