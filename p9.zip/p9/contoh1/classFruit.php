<?php
class Fruit {
    // Properties or variables
    public $name;
    public $color;

    // Setters
    function set_name($name) {
        $this->name = $name;
    }

    function set_color($color) {
        $this->color = $color;
    }

    // Getters
    function get_name() {
        return $this->name;
    }

    function get_color() {
        return $this->color;
    }
}
?>
