<?php
// Include the class definition
require_once 'nilaiSantri.php';

// Create an instance of the NilaiSantri class
$ns1 = new NilaiSantri();

// Set the properties
$ns1->nama = 'Fulan';
$ns1->nilai = 70;

// Display information about the student
echo $ns1->nama . ' Kuliah di ' . $ns1->sekolah;
echo '<br/>Hasil Ujian: ' . $ns1->nilai . ' dinyatakan ' . $ns1->getHasil();
?>
