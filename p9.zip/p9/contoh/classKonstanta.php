<?php
// Include the class definition
require_once 'classStatic.php';

// Access static member variables of the Matematika class
Matematika::$counter++;
Matematika::$counter++;
Matematika::naikanCounter();

// Display the current value of the counter
echo 'Counter Sekarang: ' . Matematika::$counter;
echo '<hr/>';

// Access static member function of the Matematika class
$sum = Matematika::tambahkan(4, 5);
echo "4 + 5 = $sum";
echo '<hr/>';

// Access constant of the Matematika class
echo 'Nilai PHI: ' . Matematika::PHI;

// Calculate and display the area of a circle with a radius of 8
$luasLingkaran = Matematika::luaslingkaran(8);
echo '<br/>Luas Lingkaran dengan Jari-jari 8 adalah: ' . $luasLingkaran;
?>
